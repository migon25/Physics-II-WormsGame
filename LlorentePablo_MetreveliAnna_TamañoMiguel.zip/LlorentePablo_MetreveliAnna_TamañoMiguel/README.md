# Physics-II-WormsGame
Physics assigment II -- This is a game made by students with their own physics engine for the subject Physics II

Author's github links:

Pablo Llorente del Castillo
https://github.com/Xymaru

Anna Metreveli
https://github.com/aNnAm2606

Miguel Tamaño Garon
https://github.com/migon25

Controls
Space to start the game, or restart after game is lost.

"A" to move your character left, "D" to move right.
"Space" to jump.

Mouse left click to launch a grenade.

Switching weapons when "1" is pressed.

Switch between velocity integrator by pressing "2".

Debug Features

F1 debug controls.

F2 for instant lose.


Github Link to the project can be found here: https://github.com/migon25/Physics-II-WormsGame


Special features:
There is an aim that moves to where your curser would be, the weapons shot will be flying that direction. 
Weapons include ice cubes, missiles and grenades.
Player has to target boxes and enemies.
Gravity, acceleration, drag, friction, collision solver, lift, impulse and player movement are coded.
 
Some of the bugs encountered:
